﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace practic4
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        Point curPoint = new Point(0, 0);
        private void Form6_Paint(object sender, PaintEventArgs e)
        {
            DrawImage(curPoint);
        }
        private void DrawImage(Point cp)
        {
            Bitmap myBitmap = new Bitmap("Bitmap11.bmp");
            Graphics g = this.CreateGraphics();
            g.DrawImage(myBitmap, cp);
        }

        private void Form6_MouseClick(object sender, MouseEventArgs e)
        {
            curPoint = e.Location;
            Invalidate();
        }
    }
}
