﻿
namespace practic4
{
    partial class _3_306_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.textBox_A = new System.Windows.Forms.TextBox();
            this.textBox_p = new System.Windows.Forms.TextBox();
            this.textBox_t = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label_A = new System.Windows.Forms.Label();
            this.label_p = new System.Windows.Forms.Label();
            this.label_t = new System.Windows.Forms.Label();
            this.button_Grafik = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_A
            // 
            this.textBox_A.Location = new System.Drawing.Point(63, 31);
            this.textBox_A.Name = "textBox_A";
            this.textBox_A.Size = new System.Drawing.Size(100, 20);
            this.textBox_A.TabIndex = 0;
            // 
            // textBox_p
            // 
            this.textBox_p.Location = new System.Drawing.Point(203, 31);
            this.textBox_p.Name = "textBox_p";
            this.textBox_p.Size = new System.Drawing.Size(100, 20);
            this.textBox_p.TabIndex = 2;
            // 
            // textBox_t
            // 
            this.textBox_t.Location = new System.Drawing.Point(337, 31);
            this.textBox_t.Name = "textBox_t";
            this.textBox_t.Size = new System.Drawing.Size(100, 20);
            this.textBox_t.TabIndex = 4;
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(12, 138);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(516, 300);
            this.chart1.TabIndex = 6;
            this.chart1.Text = "chart1";
            // 
            // label_A
            // 
            this.label_A.AutoSize = true;
            this.label_A.Location = new System.Drawing.Point(101, 12);
            this.label_A.Name = "label_A";
            this.label_A.Size = new System.Drawing.Size(14, 13);
            this.label_A.TabIndex = 7;
            this.label_A.Text = "A";
            // 
            // label_p
            // 
            this.label_p.AutoSize = true;
            this.label_p.Location = new System.Drawing.Point(244, 12);
            this.label_p.Name = "label_p";
            this.label_p.Size = new System.Drawing.Size(13, 13);
            this.label_p.TabIndex = 8;
            this.label_p.Text = "p";
            // 
            // label_t
            // 
            this.label_t.AutoSize = true;
            this.label_t.Location = new System.Drawing.Point(368, 12);
            this.label_t.Name = "label_t";
            this.label_t.Size = new System.Drawing.Size(10, 13);
            this.label_t.TabIndex = 9;
            this.label_t.Text = "t";
            // 
            // button_Grafik
            // 
            this.button_Grafik.Location = new System.Drawing.Point(169, 71);
            this.button_Grafik.Name = "button_Grafik";
            this.button_Grafik.Size = new System.Drawing.Size(160, 61);
            this.button_Grafik.TabIndex = 13;
            this.button_Grafik.Text = "button1";
            this.button_Grafik.UseVisualStyleBackColor = true;
            this.button_Grafik.Click += new System.EventHandler(this.button_Grafik_Click);
            // 
            // _3_306_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 453);
            this.Controls.Add(this.button_Grafik);
            this.Controls.Add(this.label_t);
            this.Controls.Add(this.label_p);
            this.Controls.Add(this.label_A);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.textBox_t);
            this.Controls.Add(this.textBox_p);
            this.Controls.Add(this.textBox_A);
            this.Name = "_3_306_2";
            this.Text = "_3_306_2";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_A;
        private System.Windows.Forms.TextBox textBox_p;
        private System.Windows.Forms.TextBox textBox_t;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label_A;
        private System.Windows.Forms.Label label_p;
        private System.Windows.Forms.Label label_t;
        private System.Windows.Forms.Button button_Grafik;
    }
}