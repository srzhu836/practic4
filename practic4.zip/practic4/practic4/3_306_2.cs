﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practic4
{
    public partial class _3_306_2 : Form
    {
        public _3_306_2()
        {
            InitializeComponent();
        }

        private void button_Grafik_Click(object sender, EventArgs e)
        {
            double A = Convert.ToDouble(textBox_A.Text);
            double p = Convert.ToDouble(textBox_p.Text);
            //double t = Convert.ToDouble(textBox_t);
            // Настраиваем тип графика (команда пишется в одну строку)
            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.
            Charting.SeriesChartType.Spline;
            // Очищаем существующие данные
            chart1.Series[0].Points.Clear();
            chart1.ChartAreas[0].AxisX.IsStartedFromZero = true;
            // Добавляем заголовок к графику функции
            chart1.Titles.Add("жиесь");
            chart1.Titles[0].Font = new Font("Utopia", 16);
            // Форматируем цвет фона области диаграммы
            chart1.ChartAreas[0].BackColor = Color.White;
            // Форматировать диаграмму
            chart1.BackColor = Color.Green;
            chart1.BackSecondaryColor = Color.WhiteSmoke;
            chart1.BorderlineColor = Color.DarkGreen;
            for (double T = 0;  T <= (5/p) ;  T+=(0.25/p))
            {
                double u = A * Math.Exp(p * T);
                chart1.Series[0].Points.AddXY(u, T);
            }
        }
    }

}
